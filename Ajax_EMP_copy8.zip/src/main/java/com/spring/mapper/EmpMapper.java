package com.spring.mapper;

import java.util.List;

import com.spring.empcopy01.EmpVO;



public interface EmpMapper {
	//List<EmpVO> getEmpEx();//getEmpdata
	List<EmpVO> getEmpdata();//getEmpdata
	List<EmpVO> getEmpdata2();
}
