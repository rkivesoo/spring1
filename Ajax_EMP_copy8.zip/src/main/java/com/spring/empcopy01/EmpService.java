package com.spring.empcopy01;

import java.util.List;

public interface EmpService {
	//List<EmpVO> getEmpEx();//getEmpdata
	List<EmpVO> getEmpdata();
	List<EmpVO> getEmpdata2();

}
